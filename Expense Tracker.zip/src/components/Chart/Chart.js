import React from "react";
import ChartBar from "./ChartBar";
import "./Chart.css";

const Chart = (props) => {
  const dataPointValues = props.dataPoint.map((dataPoint) => dataPoint.value);
  //returns the array of object
  // console.log(dataPointValues);
  //returns the element of each array
  // console.log(...dataPointValues);
  const totalMaximumValue = Math.max(...dataPointValues);
  return (
    <div className="chart">
      {props.dataPoint.map((dataPoint) => (
        <ChartBar
          key={dataPoint.label}
          value={dataPoint.value}
          maxValue={totalMaximumValue}
          label={dataPoint.label}
        />
      ))}
    </div>
  );
};

export default Chart;
