import React, { useState } from "react";
import "./NewExpense.css";
import ExpenseForm from "./ExpenseForm";

const NewExpense = (props) => {
  const [isEditing, setIsEditing] = useState(true);
  const expenseDataHandler = (enteredExpenseData) => {
    const expenseData = {
      ...enteredExpenseData,
      id: Math.random().toString(),
    };
    console.log(expenseData);
    //sendin the data received from expenseForm to app.js
    props.onAddExpense(expenseData);
    setIsEditing(!isEditing);
  };
  const showFormHandler = () => {
    setIsEditing(!isEditing);
  };
  const cancelClicked = () => {
    setIsEditing(!isEditing);
  };
  return (
    <div className="new-expense">
      {/* Data is comming from the Expenseform */}
      {isEditing && <button onClick={showFormHandler}>Add New Expense</button>}
      {!isEditing && (
        <ExpenseForm
          onSaveExpenseData={expenseDataHandler}
          onCancelClicked={cancelClicked}
        />
      )}
    </div>
  );
};

export default NewExpense;
